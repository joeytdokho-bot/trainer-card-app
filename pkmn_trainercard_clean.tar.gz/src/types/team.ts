export type TeamSlot = {
  speciesId?: number | null; // Index in POKEMON_DATA array
  nickname: string;
  shiny: boolean;
};

export type Team = {
  trainerName: string;
  slots: TeamSlot[];
};