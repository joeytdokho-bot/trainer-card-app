export interface SpriteParams {
  speciesId: number;
  formKey?: string;
  shiny?: boolean;
}

export function getSpriteUrl({ speciesId, formKey, shiny = false }: SpriteParams): string {
  let pokemonId = speciesId;
  
  // Map forms to their PokeAPI IDs
  const formMapping: { [key: string]: number } = {
    // Alolan Forms
    '19-Alola': 10091, // Rattata
    '20-Alola': 10092, // Raticate
    '26-Alola': 10100, // Raichu
    '27-Alola': 10103, // Sandshrew
    '28-Alola': 10104, // Sandslash
    '37-Alola': 10105, // Vulpix
    '38-Alola': 10106, // Ninetales
    '50-Alola': 10109, // Diglett
    '51-Alola': 10110, // Dugtrio
    '52-Alola': 10101, // Meowth
    '53-Alola': 10102, // Persian
    '74-Alola': 10107, // Geodude
    '75-Alola': 10108, // Graveler
    '76-Alola': 10111, // Golem
    '88-Alola': 10112, // Grimer
    '89-Alola': 10113, // Muk
    '103-Alola': 10114, // Exeggutor
    '105-Alola': 10115, // Marowak
    
    // Mega Forms
    '3-Mega': 10033, // Venusaur
    '6-Mega X': 10034, // Charizard X
    '6-Mega Y': 10035, // Charizard Y
    '9-Mega': 10036, // Blastoise
    '15-Mega': 10090, // Beedrill
    '18-Mega': 10073, // Pidgeot
    '65-Mega': 10037, // Alakazam
    '80-Mega': 10071, // Slowbro
    '94-Mega': 10038, // Gengar
    '115-Mega': 10039, // Kangaskhan
    '127-Mega': 10040, // Pinsir
    '130-Mega': 10041, // Gyarados
    '142-Mega': 10042, // Aerodactyl
    '150-Mega X': 10043, // Mewtwo X
    '150-Mega Y': 10044, // Mewtwo Y
  };
  
  if (formKey) {
    const formId = `${speciesId}-${formKey}`;
    if (formMapping[formId]) {
      pokemonId = formMapping[formId];
    }
  }
  
  // Use PokeAPI pixelated sprites exclusively - single source for everything
  const baseUrl = 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon';
  
  if (shiny) {
    return `${baseUrl}/shiny/${pokemonId}.png`;
  } else {
    return `${baseUrl}/${pokemonId}.png`;
  }
}

function getShowdownFormSuffix(formKey?: string): string {
  if (!formKey) return '';
  
  const form = formKey.toLowerCase();
  
  // Common form mappings for showdown sprite naming
  if (form === 'mega x') return '-megax';
  if (form === 'mega y') return '-megay';  
  if (form === 'mega') return '-mega';
  if (form.includes('gigantamax')) return '-gmax';
  if (form.includes('alola')) return '-alola';
  if (form.includes('galar')) return '-galar';
  if (form.includes('hisuian')) return '-hisui';
  if (form.includes('origin')) return '-origin';
  if (form.includes('primal')) return '-primal';
  
  return '';
}