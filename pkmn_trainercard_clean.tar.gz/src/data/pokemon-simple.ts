export type Pokemon = {
  id: number;
  name: string;
  form?: string;
  types: string[];
};

// Complete Gen 1 Pokemon (1-151) with ALL forms, regionals, and Megas
export const POKEMON_DATA: Pokemon[] = [
  // #001-003: Bulbasaur Line
  { id: 1, name: "Bulbasaur", types: ["Grass", "Poison"] },
  { id: 2, name: "Ivysaur", types: ["Grass", "Poison"] },
  { id: 3, name: "Venusaur", types: ["Grass", "Poison"] },
  { id: 3, name: "Venusaur", form: "Mega", types: ["Grass", "Poison"] },
  
  // #004-006: Charmander Line
  { id: 4, name: "Charmander", types: ["Fire"] },
  { id: 5, name: "Charmeleon", types: ["Fire"] },
  { id: 6, name: "Charizard", types: ["Fire", "Flying"] },
  { id: 6, name: "Charizard", form: "Mega X", types: ["Fire", "Dragon"] },
  { id: 6, name: "Charizard", form: "Mega Y", types: ["Fire", "Flying"] },
  
  // #007-009: Squirtle Line
  { id: 7, name: "Squirtle", types: ["Water"] },
  { id: 8, name: "Wartortle", types: ["Water"] },
  { id: 9, name: "Blastoise", types: ["Water"] },
  { id: 9, name: "Blastoise", form: "Mega", types: ["Water"] },
  
  // #010-012: Caterpie Line
  { id: 10, name: "Caterpie", types: ["Bug"] },
  { id: 11, name: "Metapod", types: ["Bug"] },
  { id: 12, name: "Butterfree", types: ["Bug", "Flying"] },
  
  // #013-015: Weedle Line
  { id: 13, name: "Weedle", types: ["Bug", "Poison"] },
  { id: 14, name: "Kakuna", types: ["Bug", "Poison"] },
  { id: 15, name: "Beedrill", types: ["Bug", "Poison"] },
  { id: 15, name: "Beedrill", form: "Mega", types: ["Bug", "Poison"] },
  
  // #016-018: Pidgey Line
  { id: 16, name: "Pidgey", types: ["Normal", "Flying"] },
  { id: 17, name: "Pidgeotto", types: ["Normal", "Flying"] },
  { id: 18, name: "Pidgeot", types: ["Normal", "Flying"] },
  { id: 18, name: "Pidgeot", form: "Mega", types: ["Normal", "Flying"] },
  
  // #019-020: Rattata Line (includes Alolan)
  { id: 19, name: "Rattata", types: ["Normal"] },
  { id: 19, name: "Rattata", form: "Alola", types: ["Dark", "Normal"] },
  { id: 20, name: "Raticate", types: ["Normal"] },
  { id: 20, name: "Raticate", form: "Alola", types: ["Dark", "Normal"] },
  
  // #021-022: Spearow Line
  { id: 21, name: "Spearow", types: ["Normal", "Flying"] },
  { id: 22, name: "Fearow", types: ["Normal", "Flying"] },
  
  // #023-024: Ekans Line
  { id: 23, name: "Ekans", types: ["Poison"] },
  { id: 24, name: "Arbok", types: ["Poison"] },
  
  // #025-026: Pikachu Line (includes Alolan Raichu)
  { id: 25, name: "Pikachu", types: ["Electric"] },
  { id: 26, name: "Raichu", types: ["Electric"] },
  { id: 26, name: "Raichu", form: "Alola", types: ["Electric", "Psychic"] },
  
  // #027-028: Sandshrew Line (includes Alolan)
  { id: 27, name: "Sandshrew", types: ["Ground"] },
  { id: 27, name: "Sandshrew", form: "Alola", types: ["Ice", "Steel"] },
  { id: 28, name: "Sandslash", types: ["Ground"] },
  { id: 28, name: "Sandslash", form: "Alola", types: ["Ice", "Steel"] },
  
  // #029-034: Nidoran Lines
  { id: 29, name: "Nidoran♀", types: ["Poison"] },
  { id: 30, name: "Nidorina", types: ["Poison"] },
  { id: 31, name: "Nidoqueen", types: ["Poison", "Ground"] },
  { id: 32, name: "Nidoran♂", types: ["Poison"] },
  { id: 33, name: "Nidorino", types: ["Poison"] },
  { id: 34, name: "Nidoking", types: ["Poison", "Ground"] },
  
  // #035-036: Clefairy Line
  { id: 35, name: "Clefairy", types: ["Fairy"] },
  { id: 36, name: "Clefable", types: ["Fairy"] },
  
  // #037-038: Vulpix Line (includes Alolan)
  { id: 37, name: "Vulpix", types: ["Fire"] },
  { id: 37, name: "Vulpix", form: "Alola", types: ["Ice"] },
  { id: 38, name: "Ninetales", types: ["Fire"] },
  { id: 38, name: "Ninetales", form: "Alola", types: ["Ice", "Fairy"] },
  
  // #039-040: Jigglypuff Line
  { id: 39, name: "Jigglypuff", types: ["Normal", "Fairy"] },
  { id: 40, name: "Wigglytuff", types: ["Normal", "Fairy"] },
  
  // #041-042: Zubat Line
  { id: 41, name: "Zubat", types: ["Poison", "Flying"] },
  { id: 42, name: "Golbat", types: ["Poison", "Flying"] },
  
  // #043-045: Oddish Line
  { id: 43, name: "Oddish", types: ["Grass", "Poison"] },
  { id: 44, name: "Gloom", types: ["Grass", "Poison"] },
  { id: 45, name: "Vileplume", types: ["Grass", "Poison"] },
  
  // #046-047: Paras Line
  { id: 46, name: "Paras", types: ["Bug", "Grass"] },
  { id: 47, name: "Parasect", types: ["Bug", "Grass"] },
  
  // #048-049: Venonat Line
  { id: 48, name: "Venonat", types: ["Bug", "Poison"] },
  { id: 49, name: "Venomoth", types: ["Bug", "Poison"] },
  
  // #050-051: Diglett Line (includes Alolan)
  { id: 50, name: "Diglett", types: ["Ground"] },
  { id: 50, name: "Diglett", form: "Alola", types: ["Ground", "Steel"] },
  { id: 51, name: "Dugtrio", types: ["Ground"] },
  { id: 51, name: "Dugtrio", form: "Alola", types: ["Ground", "Steel"] },
  
  // #052-053: Meowth Line (includes Alolan)
  { id: 52, name: "Meowth", types: ["Normal"] },
  { id: 52, name: "Meowth", form: "Alola", types: ["Dark"] },
  { id: 53, name: "Persian", types: ["Normal"] },
  { id: 53, name: "Persian", form: "Alola", types: ["Dark"] },
  
  // #054-055: Psyduck Line
  { id: 54, name: "Psyduck", types: ["Water"] },
  { id: 55, name: "Golduck", types: ["Water"] },
  
  // #056-057: Mankey Line
  { id: 56, name: "Mankey", types: ["Fighting"] },
  { id: 57, name: "Primeape", types: ["Fighting"] },
  
  // #058-059: Growlithe Line
  { id: 58, name: "Growlithe", types: ["Fire"] },
  { id: 59, name: "Arcanine", types: ["Fire"] },
  
  // #060-062: Poliwag Line
  { id: 60, name: "Poliwag", types: ["Water"] },
  { id: 61, name: "Poliwhirl", types: ["Water"] },
  { id: 62, name: "Poliwrath", types: ["Water", "Fighting"] },
  
  // #063-065: Abra Line
  { id: 63, name: "Abra", types: ["Psychic"] },
  { id: 64, name: "Kadabra", types: ["Psychic"] },
  { id: 65, name: "Alakazam", types: ["Psychic"] },
  { id: 65, name: "Alakazam", form: "Mega", types: ["Psychic"] },
  
  // #066-068: Machop Line
  { id: 66, name: "Machop", types: ["Fighting"] },
  { id: 67, name: "Machoke", types: ["Fighting"] },
  { id: 68, name: "Machamp", types: ["Fighting"] },
  
  // #069-071: Bellsprout Line
  { id: 69, name: "Bellsprout", types: ["Grass", "Poison"] },
  { id: 70, name: "Weepinbell", types: ["Grass", "Poison"] },
  { id: 71, name: "Victreebel", types: ["Grass", "Poison"] },
  
  // #072-073: Tentacool Line
  { id: 72, name: "Tentacool", types: ["Water", "Poison"] },
  { id: 73, name: "Tentacruel", types: ["Water", "Poison"] },
  
  // #074-076: Geodude Line (includes Alolan)
  { id: 74, name: "Geodude", types: ["Rock", "Ground"] },
  { id: 74, name: "Geodude", form: "Alola", types: ["Rock", "Electric"] },
  { id: 75, name: "Graveler", types: ["Rock", "Ground"] },
  { id: 75, name: "Graveler", form: "Alola", types: ["Rock", "Electric"] },
  { id: 76, name: "Golem", types: ["Rock", "Ground"] },
  { id: 76, name: "Golem", form: "Alola", types: ["Rock", "Electric"] },
  
  // #077-078: Ponyta Line
  { id: 77, name: "Ponyta", types: ["Fire"] },
  { id: 78, name: "Rapidash", types: ["Fire"] },
  
  // #079-080: Slowpoke Line
  { id: 79, name: "Slowpoke", types: ["Water", "Psychic"] },
  { id: 80, name: "Slowbro", types: ["Water", "Psychic"] },
  { id: 80, name: "Slowbro", form: "Mega", types: ["Water", "Psychic"] },
  
  // #081-082: Magnemite Line
  { id: 81, name: "Magnemite", types: ["Electric", "Steel"] },
  { id: 82, name: "Magneton", types: ["Electric", "Steel"] },
  
  // #083: Farfetch'd
  { id: 83, name: "Farfetch'd", types: ["Normal", "Flying"] },
  
  // #084-085: Doduo Line
  { id: 84, name: "Doduo", types: ["Normal", "Flying"] },
  { id: 85, name: "Dodrio", types: ["Normal", "Flying"] },
  
  // #086-087: Seel Line
  { id: 86, name: "Seel", types: ["Water"] },
  { id: 87, name: "Dewgong", types: ["Water", "Ice"] },
  
  // #088-089: Grimer Line (includes Alolan)
  { id: 88, name: "Grimer", types: ["Poison"] },
  { id: 88, name: "Grimer", form: "Alola", types: ["Poison", "Dark"] },
  { id: 89, name: "Muk", types: ["Poison"] },
  { id: 89, name: "Muk", form: "Alola", types: ["Poison", "Dark"] },
  
  // #090-091: Shellder Line
  { id: 90, name: "Shellder", types: ["Water"] },
  { id: 91, name: "Cloyster", types: ["Water", "Ice"] },
  
  // #092-094: Gastly Line
  { id: 92, name: "Gastly", types: ["Ghost", "Poison"] },
  { id: 93, name: "Haunter", types: ["Ghost", "Poison"] },
  { id: 94, name: "Gengar", types: ["Ghost", "Poison"] },
  { id: 94, name: "Gengar", form: "Mega", types: ["Ghost", "Poison"] },
  
  // #095: Onix
  { id: 95, name: "Onix", types: ["Rock", "Ground"] },
  
  // #096-097: Drowzee Line
  { id: 96, name: "Drowzee", types: ["Psychic"] },
  { id: 97, name: "Hypno", types: ["Psychic"] },
  
  // #098-099: Krabby Line
  { id: 98, name: "Krabby", types: ["Water"] },
  { id: 99, name: "Kingler", types: ["Water"] },
  
  // #100-101: Voltorb Line
  { id: 100, name: "Voltorb", types: ["Electric"] },
  { id: 101, name: "Electrode", types: ["Electric"] },
  
  // #102-103: Exeggcute Line (includes Alolan Exeggutor)
  { id: 102, name: "Exeggcute", types: ["Grass", "Psychic"] },
  { id: 103, name: "Exeggutor", types: ["Grass", "Psychic"] },
  { id: 103, name: "Exeggutor", form: "Alola", types: ["Grass", "Dragon"] },
  
  // #104-105: Cubone Line (includes Alolan Marowak)
  { id: 104, name: "Cubone", types: ["Ground"] },
  { id: 105, name: "Marowak", types: ["Ground"] },
  { id: 105, name: "Marowak", form: "Alola", types: ["Fire", "Ghost"] },
  
  // #106-107: Hitmon Line
  { id: 106, name: "Hitmonlee", types: ["Fighting"] },
  { id: 107, name: "Hitmonchan", types: ["Fighting"] },
  
  // #108: Lickitung
  { id: 108, name: "Lickitung", types: ["Normal"] },
  
  // #109-110: Koffing Line
  { id: 109, name: "Koffing", types: ["Poison"] },
  { id: 110, name: "Weezing", types: ["Poison"] },
  
  // #111-112: Rhyhorn Line
  { id: 111, name: "Rhyhorn", types: ["Ground", "Rock"] },
  { id: 112, name: "Rhydon", types: ["Ground", "Rock"] },
  
  // #113: Chansey
  { id: 113, name: "Chansey", types: ["Normal"] },
  
  // #114: Tangela
  { id: 114, name: "Tangela", types: ["Grass"] },
  
  // #115: Kangaskhan
  { id: 115, name: "Kangaskhan", types: ["Normal"] },
  { id: 115, name: "Kangaskhan", form: "Mega", types: ["Normal"] },
  
  // #116-117: Horsea Line
  { id: 116, name: "Horsea", types: ["Water"] },
  { id: 117, name: "Seadra", types: ["Water"] },
  
  // #118-119: Goldeen Line
  { id: 118, name: "Goldeen", types: ["Water"] },
  { id: 119, name: "Seaking", types: ["Water"] },
  
  // #120-121: Staryu Line
  { id: 120, name: "Staryu", types: ["Water"] },
  { id: 121, name: "Starmie", types: ["Water", "Psychic"] },
  
  // #122: Mr. Mime
  { id: 122, name: "Mr. Mime", types: ["Psychic", "Fairy"] },
  
  // #123: Scyther
  { id: 123, name: "Scyther", types: ["Bug", "Flying"] },
  
  // #124: Jynx
  { id: 124, name: "Jynx", types: ["Ice", "Psychic"] },
  
  // #125: Electabuzz
  { id: 125, name: "Electabuzz", types: ["Electric"] },
  
  // #126: Magmar
  { id: 126, name: "Magmar", types: ["Fire"] },
  
  // #127: Pinsir
  { id: 127, name: "Pinsir", types: ["Bug"] },
  { id: 127, name: "Pinsir", form: "Mega", types: ["Bug", "Flying"] },
  
  // #128: Tauros
  { id: 128, name: "Tauros", types: ["Normal"] },
  
  // #129-130: Magikarp Line
  { id: 129, name: "Magikarp", types: ["Water"] },
  { id: 130, name: "Gyarados", types: ["Water", "Flying"] },
  { id: 130, name: "Gyarados", form: "Mega", types: ["Water", "Dark"] },
  
  // #131: Lapras
  { id: 131, name: "Lapras", types: ["Water", "Ice"] },
  
  // #132: Ditto
  { id: 132, name: "Ditto", types: ["Normal"] },
  
  // #133-136: Eevee Line
  { id: 133, name: "Eevee", types: ["Normal"] },
  { id: 134, name: "Vaporeon", types: ["Water"] },
  { id: 135, name: "Jolteon", types: ["Electric"] },
  { id: 136, name: "Flareon", types: ["Fire"] },
  
  // #137: Porygon
  { id: 137, name: "Porygon", types: ["Normal"] },
  
  // #138-139: Omanyte Line
  { id: 138, name: "Omanyte", types: ["Rock", "Water"] },
  { id: 139, name: "Omastar", types: ["Rock", "Water"] },
  
  // #140-141: Kabuto Line
  { id: 140, name: "Kabuto", types: ["Rock", "Water"] },
  { id: 141, name: "Kabutops", types: ["Rock", "Water"] },
  
  // #142: Aerodactyl
  { id: 142, name: "Aerodactyl", types: ["Rock", "Flying"] },
  { id: 142, name: "Aerodactyl", form: "Mega", types: ["Rock", "Flying"] },
  
  // #143: Snorlax
  { id: 143, name: "Snorlax", types: ["Normal"] },
  
  // #144-146: Legendary Birds
  { id: 144, name: "Articuno", types: ["Ice", "Flying"] },
  { id: 145, name: "Zapdos", types: ["Electric", "Flying"] },
  { id: 146, name: "Moltres", types: ["Fire", "Flying"] },
  
  // #147-149: Dratini Line
  { id: 147, name: "Dratini", types: ["Dragon"] },
  { id: 148, name: "Dragonair", types: ["Dragon"] },
  { id: 149, name: "Dragonite", types: ["Dragon", "Flying"] },
  
  // #150: Mewtwo
  { id: 150, name: "Mewtwo", types: ["Psychic"] },
  { id: 150, name: "Mewtwo", form: "Mega X", types: ["Psychic", "Fighting"] },
  { id: 150, name: "Mewtwo", form: "Mega Y", types: ["Psychic"] },
  
  // #151: Mew
  { id: 151, name: "Mew", types: ["Psychic"] },
];

// Helper function to get display name for a Pokemon
export const getPokemonDisplayName = (pokemon: Pokemon): string => {
  return pokemon.form ? `${pokemon.name} (${pokemon.form})` : pokemon.name;
};

// Helper function to find Pokemon by ID (base species ID, returns first match)
export const findPokemonById = (id: number): Pokemon | undefined => {
  return POKEMON_DATA.find(pokemon => pokemon.id === id);
};

// Helper function to get all forms of a Pokemon
export const getAllFormsById = (id: number): Pokemon[] => {
  return POKEMON_DATA.filter(pokemon => pokemon.id === id);
};

// Helper function to get type colors that match each type
export const getTypeColor = (type: string): string => {
  const typeColors: { [key: string]: string } = {
    Normal: '#A8A878',
    Fire: '#F08030', 
    Water: '#6890F0',
    Electric: '#F8D030',
    Grass: '#78C850',
    Ice: '#98D8D8',
    Fighting: '#C03028',
    Poison: '#A040A0',
    Ground: '#E0C068',
    Flying: '#A890F0',
    Psychic: '#F85888',
    Bug: '#A8B820',
    Rock: '#B8A038',
    Ghost: '#705898',
    Dragon: '#7038F8',
    Dark: '#705848',
    Steel: '#B8B8D0',
    Fairy: '#EE99AC',
  };
  return typeColors[type] || '#A8A878';
};