'use client';

import { useState } from 'react';
import Image from 'next/image';
import { Team, TeamSlot } from '@/types/team';
import { POKEMON_DATA, getPokemonDisplayName, getTypeColor } from '@/data/pokemon-simple';
import { getSpriteUrl } from '@/lib/spriteResolver';

export function TeamBuilder() {
  const [team, setTeam] = useState<Team>({
    trainerName: '',
    slots: Array.from({ length: 6 }, (): TeamSlot => ({
      speciesId: null,
      nickname: '',
      shiny: false,
    })),
  });

  const updateSlot = (index: number, field: keyof TeamSlot, value: string | boolean | number | null) => {
    setTeam(prev => ({
      ...prev,
      slots: prev.slots.map((slot, i) => 
        i === index 
          ? { ...slot, [field]: value }
          : slot
      ),
    }));
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <label className="block text-sm font-medium text-black mb-2">
          Trainer Name
        </label>
        <input
          type="text"
          value={team.trainerName}
          onChange={(e) => setTeam(prev => ({ ...prev, trainerName: e.target.value }))}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-black"
          placeholder="Enter trainer name"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {team.slots.map((slot, index) => (
          <div
            key={index}
            className="bg-white p-4 rounded-lg shadow-md border border-gray-200"
          >
            <div className="mb-3">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-lg font-semibold text-black">
                  Slot {index + 1}
                </h3>
              </div>
              
              {slot.speciesId !== null && (
                <div className="flex items-center space-x-3 mb-3">
                  <Image
                    src={getSpriteUrl({
                      speciesId: POKEMON_DATA[slot.speciesId]?.id || 1,
                      formKey: POKEMON_DATA[slot.speciesId]?.form,
                      shiny: slot.shiny
                    })}
                    alt={slot.nickname || getPokemonDisplayName(POKEMON_DATA[slot.speciesId])}
                    width={80}
                    height={80}
                    className="pixelated"
                    unoptimized
                  />
                  <div className="flex flex-col flex-1">
                    <span className="text-black font-medium text-sm mb-2">
                      {slot.nickname || getPokemonDisplayName(POKEMON_DATA[slot.speciesId])}
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {POKEMON_DATA[slot.speciesId]?.types.map((type, typeIndex) => (
                        <span
                          key={typeIndex}
                          className="px-3 py-1 rounded-full text-white text-xs font-bold uppercase"
                          style={{ backgroundColor: getTypeColor(type) }}
                        >
                          {type}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium text-black mb-1">
                  Species
                </label>
                <select
                  value={slot.speciesId || ''}
                  onChange={(e) => updateSlot(index, 'speciesId', e.target.value ? parseInt(e.target.value) : null)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-black"
                >
                  <option value="">Select a Pokémon</option>
                  {POKEMON_DATA.map((pokemon, pokemonIndex) => (
                    <option key={pokemonIndex} value={pokemonIndex}>
                      #{pokemon.id.toString().padStart(3, '0')} - {getPokemonDisplayName(pokemon)}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-black mb-1">
                  Nickname
                </label>
                <input
                  type="text"
                  value={slot.nickname}
                  onChange={(e) => updateSlot(index, 'nickname', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-black"
                  placeholder="Enter nickname"
                />
              </div>

              <div className="flex items-center">
                <input
                  type="checkbox"
                  id={`shiny-${index}`}
                  checked={slot.shiny}
                  onChange={(e) => updateSlot(index, 'shiny', e.target.checked)}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                />
                <label htmlFor={`shiny-${index}`} className="ml-2 text-sm text-black">
                  Shiny
                </label>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}