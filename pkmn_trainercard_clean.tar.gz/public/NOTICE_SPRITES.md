# Sprite Attribution Notice

This application displays Pokémon sprites that are hotlinked from external, community-hosted sources.

## Sources

- **PokeAPI Sprites**: `https://raw.githubusercontent.com/PokeAPI/sprites/master/`
  - Official artwork sprites
  - Community-maintained sprite repository

- **Pokémon Showdown**: `https://play.pokemonshowdown.com/sprites/`
  - Gen 5 style sprites with form variants
  - Shiny sprite variants
  - Mega, Gigantamax, and regional form sprites

## Copyright

All Pokémon sprites, names, and related intellectual property are © Nintendo, Game Freak, and The Pokémon Company.

These sprites are used for educational and fan purposes only. No sprites are stored locally in this application - all images are hotlinked from their respective community-hosted sources.

## Community Credits

- PokeAPI team for maintaining the sprite repository
- Pokémon Showdown for providing comprehensive sprite collections
- Smogon community for sprite contributions

If you are a copyright holder and have concerns about sprite usage, please contact the respective hosting platforms directly.